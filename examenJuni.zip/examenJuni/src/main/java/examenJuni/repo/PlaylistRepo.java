package examenJuni.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import examenJuni.Entitys.Playlist;

@Repository
public interface PlaylistRepo extends CrudRepository<Playlist, Integer>{
	
//	@Query(value = "select * from playlist where Playlistid = ?1 limit 1", nativeQuery = true)
//	public Playlist(@Param("name") String name)

}
