package examenJuni.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import examenJuni.Entitys.Track;

@Repository
public interface TrackRepo extends CrudRepository<Track, Integer>{
	
	

}
