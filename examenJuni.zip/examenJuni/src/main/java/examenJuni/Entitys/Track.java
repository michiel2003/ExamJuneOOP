package examenJuni.Entitys;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "track")
public class Track {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "trackid")
	public Integer trackId;
	
	@Column(name = "name")
	public String name;
	
	@Column(name = "albumid")
	public Integer albumId;
	
	@Column(name = "mediatypeid")
	public Integer madiaTypeId;
	
	@Column(name = "genreid")
	public Integer genreId;
	
	@Column(name = "composer")
	public String composer;
	
	@Column(name = "milliseconds")
	public Integer milliseconds;
	
	@Column(name = "bytes")
	public Integer bytes;
	
	@Column(name = "unitprice")
	public Double unitPrice;
	
	@ManyToMany(mappedBy = "tracks")
	public List<Playlist> playlists;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((albumId == null) ? 0 : albumId.hashCode());
		result = prime * result + ((bytes == null) ? 0 : bytes.hashCode());
		result = prime * result + ((composer == null) ? 0 : composer.hashCode());
		result = prime * result + ((milliseconds == null) ? 0 : milliseconds.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Track other = (Track) obj;
		if (albumId == null) {
			if (other.albumId != null)
				return false;
		} else if (!albumId.equals(other.albumId))
			return false;
		if (bytes == null) {
			if (other.bytes != null)
				return false;
		} else if (!bytes.equals(other.bytes))
			return false;
		if (composer == null) {
			if (other.composer != null)
				return false;
		} else if (!composer.equals(other.composer))
			return false;
		if (milliseconds == null) {
			if (other.milliseconds != null)
				return false;
		} else if (!milliseconds.equals(other.milliseconds))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	

}
