package examenJuni.Entitys;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "playlist")
public class Playlist {

	@Id
	@Column(name = "playlistid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer playlistId;

	@Column(name = "name")
	public String name;

	@ManyToMany
	@JoinTable(name = "playlisttrack", joinColumns = @JoinColumn(name = "Playlistid"), inverseJoinColumns = @JoinColumn(name = "trackid"))
	public List<Track> tracks;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Playlist other = (Playlist) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	

}
