package examenJuni.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import examenJuni.Entitys.Playlist;
import examenJuni.repo.PlaylistRepo;

@RestController
public class PlayListController {
	
	@Autowired
	PlaylistRepo Prep;
	
	@RequestMapping("/Playlist/newPlaylist")
	public void newPlaylist(@RequestParam String name) {
		Playlist newlist = new Playlist();
		newlist.name = name;
		Prep.save(newlist);
	}

}
