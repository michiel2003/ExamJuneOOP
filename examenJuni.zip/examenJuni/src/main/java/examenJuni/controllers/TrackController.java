package examenJuni.controllers;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import examenJuni.Entitys.Playlist;
import examenJuni.Entitys.Track;
import examenJuni.repo.PlaylistRepo;
import examenJuni.repo.TrackRepo;

@RestController
public class TrackController {
	
	@Autowired
	TrackRepo Trep;
	
	@Autowired
	PlaylistRepo Prep;
	
	@RequestMapping("/Track/newTrack")
	public boolean addNewTrack(@RequestParam String name, @RequestParam Integer mediaTypeId, @RequestParam Integer milliseconds, @RequestParam Double unitPrice, @RequestParam Integer bytes) {
		Track newTrack = new Track();
		if(testNewTrack(name, milliseconds, bytes)) {
			return false;
		}
		testNewTrack(name, milliseconds, bytes);
		newTrack.bytes = bytes;
		newTrack.name = name;
		newTrack.madiaTypeId = mediaTypeId;
		newTrack.milliseconds = milliseconds;
		newTrack.unitPrice = unitPrice;
		Trep.save(newTrack);
		return true;
	}

	public boolean testNewTrack(String name, Integer milliseconds, Integer bytes) {
		if(name.contains("fuck")) {
			return true;
		}if(bytes < 10000) {
			return true;
		}if(milliseconds < 5000) {
			return true;
		}return false;
	}
	
	@RequestMapping("/Track/addTrackToPlaylist")
	public void addTrackToPlaylist(@RequestParam Integer pid, @RequestParam Integer lid) {
		Iterable<Playlist> playlist = toIterable(Prep.findById(pid));
		Iterable<Track> tracklist = toIterable(Trep.findById(lid));
		for(Playlist p: playlist) {
			for(Track t:tracklist) {
				p.tracks.add(t);
				Prep.save(p);
			}
		}
	}
	
	@RequestMapping("/Track/deleteTrackFromPlaylist")
	public void deleteTrackFromPlaylist(@RequestParam Integer pid, @RequestParam Integer lid) {
		Iterable<Playlist> playlist = toIterable(Prep.findById(pid));
		Iterable<Track> tracklist = toIterable(Trep.findById(lid));
		for(Playlist p: playlist) {
			for(Track t:tracklist) {
				p.tracks.remove(t);
				Prep.save(p);
			}
		}
	}
	
	public <T> Iterable<T> toIterable(Optional<T> o) {
	    return o.map(Collections::singleton)
	            .orElseGet(Collections::emptySet);
	}

}
