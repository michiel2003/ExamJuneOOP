package examenJuni.frame;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class OmzetFrame {
	
	public static void main(String[] args) {
		OmzetFrame omzet = new OmzetFrame();
		omzet.generateOmzetFrame();
	}
	
	public void generateOmzetFrame() {
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
	
		String options[] = {"US Dollar X2", "US Dollar X3", "US Dollar X4"};
		
		JComboBox<String> dropDown = new JComboBox<>(options);
		
		JTextField valueEuro = new JTextField();
		valueEuro.setPreferredSize(new Dimension(100, 20));
		
		JTextField result = new JTextField();
		result.setEditable(false);
		result.setPreferredSize(new Dimension(100, 20));
		
		JButton convert = new JButton("Comvert");
		convert.setPreferredSize(new Dimension(20, 20));
		panel.setLayout(new BorderLayout());
		
		frame.add(panel);
		
		panel.add(convert, BorderLayout.CENTER);
		panel.add(dropDown, BorderLayout.SOUTH);
		panel.add(valueEuro, BorderLayout.WEST);
		panel.add(result, BorderLayout.EAST);
	
		convert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println(dropDown.getSelectedItem());
				if(dropDown.getSelectedIndex() == 0) {
					result.setText(Integer.parseInt(valueEuro.getText())*2 + "");
				}
				if(dropDown.getSelectedIndex() == 1) {
					result.setText(Integer.parseInt(valueEuro.getText())*3 + "");
				}
				if(dropDown.getSelectedIndex() == 2) {
					result.setText(Integer.parseInt(valueEuro.getText())*4 + "");
				}
				
			}
		});

		
		
		frame.setSize(new Dimension(800, 100));
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
	}

}
