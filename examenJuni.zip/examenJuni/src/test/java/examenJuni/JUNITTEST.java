package examenJuni;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import examenJuni.Entitys.Playlist;
import examenJuni.Entitys.Track;
import examenJuni.controllers.TrackController;

public class JUNITTEST {
	
	@Test
	public void TestTrack() {
		Track track = new Track();
		Track track2 = new Track();
		assertTrue(track.hashCode() == track2.hashCode());
		assertTrue(track.equals(track2));
		track.name = "ee";
		track2.name = "aa";
		assertFalse(track.equals(track2));
		assertFalse(track.hashCode() == track2.hashCode());
	}
	
	@Test
	public void TestPlaylist() {
		Playlist play = new Playlist();
		Playlist play2 = new Playlist();
		assertTrue(play.hashCode() == play2.hashCode());
		assertTrue(play.equals(play2));
		play.name = "ee";
		play2.name = "aa";
		assertFalse(play.equals(play2));
		assertFalse(play.hashCode() == play2.hashCode());
	}
	
	@Test
	public void TestAddTrack() {
		TrackController control = new TrackController();
		// this should not work because fuck is not allowed
		assertFalse(control.addNewTrack("fuck", 1, 6000, 20d, 90000));
		// this should not work because the minimum is 5000 milliseconds
		assertFalse(control.addNewTrack("allowedName", 1, 2000, 20d, 90000));
		// this should not work because the minimum is 10000 bytes
		assertFalse(control.addNewTrack("allowedName", 1, 6000, 20d, 1));
	}

}
